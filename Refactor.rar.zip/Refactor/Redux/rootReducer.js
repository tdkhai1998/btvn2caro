import { combineReducers } from 'redux';

import history from './history/reducer';
import infoUser from './infoUser/reducer';
import isFetching from './isFetching/reducer';
import isSorted from './isSorted/reducer';
import message from './message/reducer';
import showModal from './showModal/reducer';
import squares from './squares/reducer';
import turn from './turn/reducer';
import user from './user/reducer';
import winnerLine from './winnerLine/reducer';

const rootReducer = combineReducers({
  history,
  infoUser,
  isFetching,
  isSorted,
  message,
  showModal,
  squares,
  turn,
  user,
  winnerLine
});

export default rootReducer;
