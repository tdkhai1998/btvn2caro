export const TYPE = {
  CHANGE: 'isSorted_change'
};
export const Sort = () => ({
  type: TYPE.SORT
});
