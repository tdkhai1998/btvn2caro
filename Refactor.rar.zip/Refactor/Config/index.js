// const serverHost = 'https://khaicaro.herokuapp.com';
const serverHost = 'http://localhost:8080';
export default serverHost;
